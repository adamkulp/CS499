package SalesTax;

public class BasicItemDecorator implements Item{
    private Item item;

    public BasicItemDecorator(Item item){
        this.item = item;
    }
    @Override
    public int getQuantity() {
        return item.getQuantity();
    }

    @Override
    public double getPrice() {
        return item.getPrice();
    }

    @Override
    public double getTotal() {
        return item.getTotal();
    }

    @Override
    public String getItemname() {
        return item.getItemname();
    }
}