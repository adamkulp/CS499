/**
 * A tax calculating program that prompts a user if they would like to open a file containing quantity(int),
 * item(string),price (double) and tax exempt status (boolean)(examples in output 1,2,3 and data.csv); if the user
 * enters 'n' the program will then ask for user input of the above mentioned variables on a loop until the user
 * inputs 'n' when asked if they would like to add another item at which time a receipt will print showing all items
 * entered, the unit price, price after tax and at the bottom a grand total and total tax entry. This program
 * calculates all taxable items at a stagnant rate of 10 % and imported items add a 5 % duty tax automatically.
 * For the program to read a file correctly the following format must be followed quantity(int),
 * item(string),price (xx.xx) and tax exempt status ('y','Y','n','N') and the line ending with a comma. I went with a
 * dynamic oop program style as opposed to a procedural style to keep things tidy and modular. I implemented an
 * interface and decorator design pattern (allows behaviors to individual objects) to allow for flexibility in
 * the future since java doesn't support multiple inheritance (as well as calculations of the import tax).
 */


package SalesTax;

import javax.swing.*;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        char moreitems;
        List<Item> items = new ArrayList<>(); // new array list for storage
        Scanner scan = new Scanner(System.in); // new scanner
        System.out.print("Do you want to load a file? (Y or N)");
        char response = scan.nextLine().trim().charAt(0);
        //if user input is true file explorer will open
        if (response == 'Y' || response == 'y') {
            JFileChooser FC = new JFileChooser();
            int RC = FC.showOpenDialog(null);
            if (RC == JFileChooser.APPROVE_OPTION) {
                scan.close();
                scan = new Scanner(FC.getSelectedFile()).useDelimiter(",");
                while (scan.hasNext()) {
                    int quantity = scan.nextInt(); //quantity of item
                    String itemname = scan.next(); //item name
                    double initprice = scan.nextDouble(); // unit price
                    char exempt = scan.next().trim().charAt(0); // is product tax exempt?
                    if (scan.hasNextLine())
                        scan.nextLine();
                    Item item = ImportTax.getItem(quantity, itemname, initprice, exempt);

                    items.add(item); // fetching data until end of document
                }


            }
        } else {
            do {

                // if user input is false we begin asking for user input
                System.out.print("Please enter Quantity of Item: ");
                //int quantity = scan.nextInt();
                int quantity = 0;
                double initprice = 0.0;
                boolean isQuantity;
                boolean isInitPrice;
                //numerical input validation
                do {
                    if (scan.hasNextInt()) {
                        quantity = scan.nextInt();
                        isQuantity = true;


                    } else {
                        System.out.print("I'm sorry but you didn't enter an integer!");
                        isQuantity = false;
                        System.out.println();
                        System.out.print("Please enter Quantity of Item: ");
                        scan.next();

                    }
                } while (!(isQuantity));
                scan.nextLine();
                System.out.print("Please enter Item name: ");
                String itemname = scan.nextLine();
                System.out.print("Please enter price of Item ($xx.xx): ");
                //numerical input validation
                do {
                    if (scan.hasNextDouble()) {
                        initprice = scan.nextDouble();
                        isInitPrice = true;


                    } else {
                        System.out.print("I'm sorry but you didn't enter a price (xx.xx)!");
                        isInitPrice = false;
                        System.out.println();
                        System.out.print("Please enter price of Item ($xx.xx): ");
                        scan.next();

                    }
                } while (!(isInitPrice));
                System.out.print("Is this Item tax exempt? (Y or N)");
                char exempt = scan.next().trim().charAt(0);
                System.out.print("Would you like to add another Item? (Y or N)");
                moreitems = scan.next().trim().charAt(0);


                Item item = ImportTax.getItem(quantity, itemname, initprice, exempt);

                items.add(item); //storing user input

            }
            while ((moreitems == 'y') || (moreitems == 'Y')); //looping until false

        }
        scan.close(); //closing scanner
        System.out.printf("%-5s\t%-27s\t%-8s\t%-5s%n",
                "QTY",
                "Item Name",
                "Unit Price",
                "Price");

        double grandTotal = 0.0; // initializing grand total for total print on receipt
        double allTax = 0.0;
        for (Item item : items) {
            System.out.printf("%5d\t%-27s\t%8.2f\t%5.2f%n",

                    item.getQuantity(), // fetch input quantity
                    item.getItemname(), // fetch input item name
                    item.getPrice(),   // fetch price
                    item.getTotal()); // fetch total


            grandTotal += item.getTotal();
            allTax = TaxableItem.getTotaltax() + ImportedItem.getTotalImport();


        }

        //receipt
        System.out.println();
        System.out.print("Sales Tax: ");
        System.out.printf("$%12.2f%n", TaxableItem.getTotaltax());
        System.out.print("Duty Tax: ");
        System.out.printf("$%13.2f%n", ImportedItem.getTotalImport());
        System.out.print("Total Taxes: ");
        System.out.printf("$%10.2f%n", allTax);
        System.out.print("Total: ");
        System.out.printf("$%16.2f%n", grandTotal);
        System.out.print("=========================================================");

    }
}