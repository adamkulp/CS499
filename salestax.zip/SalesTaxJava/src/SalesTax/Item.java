package SalesTax;

public interface Item {
    int getQuantity();
    double getPrice();
    double getTotal();
    String getItemname();
}

