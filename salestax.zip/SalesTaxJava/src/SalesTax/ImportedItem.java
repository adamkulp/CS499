package SalesTax;

public class ImportedItem extends BasicItemDecorator {
    public ImportedItem(Item item) {
        super(item);
    }

    private double importfee = 0.0;
    static double importTax = 0.0;


    public double getImportFee() {

        // import fee calculations
        double importfee = getPrice() * 0.05;
        importfee = Math.ceil(importfee * 20.0) / 20.0;
        if (this.importfee == 0.0) {
            importTax += importfee;
            this.importfee = importTax;
        }
        return importfee;
    }

    @Override
    public double getTotal() {
        return super.getTotal() + getImportFee();
    }

    public static double getTotalImport() {
        return importTax;
    }
}