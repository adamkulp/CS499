package SalesTax;

public class ImportTax {
    // if input name contains 'import' adding 5 percent tax (cases for each exception)
    public static Item getItem(int quantity, String name, double price, char exempt) {
        Item item = null;
        if (name.toLowerCase().contains("import")) {
            if (exempt == 'N' || exempt == 'n') {
                // The item is both taxable and an import
                BasicItem bi = new BasicItem(quantity, name, price);
                TaxableItem tbi = new TaxableItem(bi);
                ImportedItem itbi = new ImportedItem(tbi);
                item = itbi;
            } else {
                // The item is an import and not taxable
                BasicItem bi = new BasicItem(quantity, name, price);
                ImportedItem ibi = new ImportedItem(bi);
                item = ibi;
            }
        } else {
            // Item is NOT an import
            if (exempt == 'N' || exempt == 'n') {
                // The item is taxable and not an import
                BasicItem bi = new BasicItem(quantity, name, price);
                TaxableItem tbi = new TaxableItem(bi);
                item = tbi;
            } else {
                // The item is not an import and not taxable
                BasicItem bi = new BasicItem(quantity, name, price);
                item = bi;
            }
        }
        return item;
    }
}


