package SalesTax;

public class BasicItem implements Item {
    private int quantity;
    private String itemname;
    private double price;


    public BasicItem() {

    }

    public BasicItem(int quantity, String itemname, double price) {
        this.quantity = quantity;
        this.itemname = itemname;
        this.price = price;


    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getTotal() {
        double newprice = (price * quantity);






        return newprice;


    }

}
