package SalesTax;

public class TaxableItem extends BasicItemDecorator {
    public TaxableItem(Item item) {
        super(item);
    }
    private double tax = 0.0;
    static double totaltax = 0.0;

    public double getTax() {

        //calculate tax and rounding
        double tax = getPrice() * getQuantity() * 0.1;
        tax = Math.ceil(tax * 20.0) / 20.0;
        if (this.tax == 0.0) {
            totaltax += tax;
            this.tax = tax;
        }
        return tax;

    }
    // total
    public double getTotal () {
        return super.getTotal() + getTax();


    }
    public static double getTotaltax(){
        return totaltax;
    }
}